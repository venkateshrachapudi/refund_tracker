# TurboTax-like Refund Status System (Proof of Concept)

This project is a secure, AI-integrated refund tracking API similar to TurboTax. It allows users to:
- 🔐 Query the status of their tax refund
- 📈 Get AI-predicted refund arrival time (ETA) if unavailable
- 🧠 Retrain the ML model nightly on new IRS outcomes

## 🔧 Features

- **FastAPI** async REST API
- **JWT OAuth2** token-based authentication
- **AES-GCM encryption** for SSN with rotating IVs
- **ONNX** model for fast vectorized inference
- **IRS Lookup Queue** with retries and exponential backoff
- **Redis Caching**
- **XGBoost Training Script** + future ONNX export
- **Modular Python Structure** with Pydantic, comments, and dependency injection

## 📦 Folder Structure

```
refund_status_poc/
│
├── app/
│   ├── main.py                # API routes
│   ├── auth.py                # JWT Auth logic
│   ├── crypto.py              # AES encryption/decryption
│   ├── ml_inference.py        # Refund ETA prediction logic
│   ├── queue_handler.py       # IRS lookup queuing
│   └── schemas.py             # Data models
│
├── models/
│   ├── train_model.py         # XGBoost training
│
├── requirements.txt
├── README.md
```

## 🚀 Running the Project

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Start the FastAPI server
uvicorn app.main:app --reload

# 3. Send API requests (after generating JWT tokens)
```

## 🧠 To-Do for Production

- Replace mock inference with real ONNX model
- Use KMS or Vault for key storage
- Add Langfuse for observability
- Integrate XGBoost nightly retraining job with error drift threshold
