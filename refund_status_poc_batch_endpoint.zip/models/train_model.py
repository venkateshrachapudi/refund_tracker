"""
Example placeholder for training the refund ETA prediction model using XGBoost.
To be converted to ONNX using skl2onnx or onnxmltools.
"""

import xgboost as xgb
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Example training dataset
df = pd.DataFrame({
    'income': [20000, 50000, 100000, 150000],
    'days_to_refund': [28, 21, 14, 10]
})

X = df[['income']]
y = df['days_to_refund']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)

model = xgb.XGBRegressor()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
print("MSE:", mean_squared_error(y_test, y_pred))
