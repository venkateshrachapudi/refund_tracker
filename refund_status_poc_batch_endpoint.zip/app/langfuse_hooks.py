"""
Langfuse-style observability logging hooks for tracing refund queries.
"""

def log_observability_trace(request_id: str, user_id: str, method: str, path: str, latency_ms: float, status: str):
    """
    Logs API call details for audit, monitoring, and drift detection.
    """
    print(f"[TRACE] req={request_id} user={user_id} path={method} {path} latency={latency_ms:.2f}ms status={status}")
