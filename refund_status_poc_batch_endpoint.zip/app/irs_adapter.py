"""
IRS Adapter Service
- Handles retry, circuit breaker, rate limiting, schema validation, and logging.
"""

import aiohttp
import time
import jsonschema
import redis
import logging
from datetime import datetime
from typing import Optional

# Redis setup for token bucket + circuit breaker
redis_client = redis.Redis(host="localhost", port=6379, db=1)

IRS_API_URL = "https://irs.gov/api/refund-status"
RATE_LIMIT_KEY = "irs_rate_limit"
CIRCUIT_BREAKER_KEY = "irs_circuit_breaker"
MAX_CALLS_PER_MINUTE = 60
CIRCUIT_BREAKER_THRESHOLD = 0.2
WINDOW = 300  # 5 minutes

# JSON Schema for validation
refund_schema = {
    "type": "object",
    "properties": {
        "status": {"type": "string"},
        "refund_date": {"type": "string", "format": "date"},
        "amount": {"type": "number"}
    },
    "required": ["status", "refund_date", "amount"]
}

async def is_circuit_open() -> bool:
    """Check if the IRS circuit breaker is open."""
    failure_rate = float(redis_client.get("irs_failure_rate") or 0)
    return failure_rate > CIRCUIT_BREAKER_THRESHOLD

async def apply_rate_limit():
    """Token bucket rate limiter."""
    tokens = int(redis_client.get(RATE_LIMIT_KEY) or MAX_CALLS_PER_MINUTE)
    if tokens <= 0:
        raise Exception("Rate limit exceeded.")
    redis_client.decr(RATE_LIMIT_KEY)

def log_request(meta: dict):
    """Logs metadata to OpenTelemetry (placeholder)."""
    print(f"[IRS_LOG] {json.dumps(meta)}")

async def fetch_irs_status(ssn: str, year: int) -> Optional[dict]:
    """Main IRS fetch function with retry, circuit breaker, and observability."""
    if await is_circuit_open():
        raise Exception("IRS Circuit breaker is OPEN")

    await apply_rate_limit()
    headers = {"Authorization": "Bearer secure-mtls-token"}  # placeholder

    retries = 0
    success = False
    start = time.time()
    result = None

    while retries < 3:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{IRS_API_URL}?ssn={ssn}&filing_year={year}", headers=headers) as resp:
                    resp.raise_for_status()
                    data = await resp.json()
                    jsonschema.validate(data, refund_schema)
                    success = True
                    result = data
                    break
        except Exception as e:
            retries += 1
            await asyncio.sleep(2 ** retries)

    latency = time.time() - start
    log_request({
        "request_id": f"irs-{int(time.time()*1000)}",
        "timestamp": datetime.utcnow().isoformat(),
        "latency_ms": latency * 1000,
        "status": "success" if success else "failure"
    })

    # update circuit breaker stats
    failures = int(redis_client.get("irs_failures") or 0)
    calls = int(redis_client.get("irs_calls") or 0) + 1
    redis_client.set("irs_calls", calls)
    if not success:
        redis_client.set("irs_failures", failures + 1)
    redis_client.set("irs_failure_rate", (failures + (0 if success else 1)) / calls)

    if result:
        return result
    else:
        raise Exception("IRS fetch failed")
