"""
Batch inference logic for refund ETA prediction using ONNX or mock logic.
Supports high-throughput vectorized prediction for scalability.
"""

import numpy as np
from typing import List, Dict
from datetime import datetime, timedelta

def predict_batch_eta(users: List[Dict]) -> List[Dict]:
    """
    Accepts a list of user dictionaries with features.
    Returns a list of predicted ETAs and confidence scores.
    """

    # Extract features into batched NumPy array
    incomes = np.array([user["income"] for user in users], dtype=np.float32)
    file_types = [user.get("file_type", "e-file") for user in users]
    states = [user.get("state", "CA") for user in users]

    # Apply vectorized logic (mocked model)
    avg_days = np.array([21 if ft == "e-file" else 28 for ft in file_types])
    eta_days = np.clip(avg_days - (incomes / 10000), 7, avg_days)
    predicted_dates = [(datetime.utcnow() + timedelta(days=int(days))).date().isoformat() for days in eta_days]

    confidences = [0.85 if ft == "e-file" else 0.75 for ft in file_types]

    return [
        {
            "user_id": users[i].get("user_id"),
            "eta": predicted_dates[i],
            "confidence": confidences[i],
            "source": "Estimated using batch AI model"
        }
        for i in range(len(users))
    ]
