"""
Handles AES-GCM encryption and decryption of sensitive data (e.g., SSNs).
"""

import os
import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

AES_KEY = os.urandom(32)
IV_LENGTH = 12

def encrypt_ssn(ssn_plain: str) -> str:
    """
    Encrypts the plaintext SSN using AES-GCM with a random IV.
    Returns base64-encoded encrypted string.
    """
    iv = os.urandom(IV_LENGTH)
    aesgcm = AESGCM(AES_KEY)
    encrypted = aesgcm.encrypt(iv, ssn_plain.encode(), None)
    return base64.b64encode(iv + encrypted).decode()

def decrypt_ssn(encrypted_ssn: str) -> str:
    """
    Decrypts the base64-encoded encrypted SSN.
    Returns the original plaintext SSN.
    """
    decoded = base64.b64decode(encrypted_ssn.encode())
    iv = decoded[:IV_LENGTH]
    ciphertext = decoded[IV_LENGTH:]
    aesgcm = AESGCM(AES_KEY)
    return aesgcm.decrypt(iv, ciphertext, None).decode()
