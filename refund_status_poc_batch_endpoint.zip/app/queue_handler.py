"""
Simulates asynchronous IRS lookup with retry and exponential backoff logic.
"""

import asyncio
import redis

redis_client = redis.Redis(host="localhost", port=6379, db=0)

async def queue_irs_lookup(ssn: str):
    """
    Queues IRS lookup by setting a status in Redis.
    Retries up to 3 times with exponential backoff if Redis fails.
    """
    retries = 0
    while retries < 3:
        try:
            await asyncio.sleep(1)
            redis_client.set(f"refund:{ssn}", "PROCESSING")
            return
        except Exception:
            await asyncio.sleep(2 ** retries)
            retries += 1
