"""
Main FastAPI application entry point for the Tax Refund Status System.
Handles API routing, JWT validation, IRS lookup simulation, and AI model inference.
"""

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.security import OAuth2PasswordBearer
from app.schemas import RefundStatusRequest, RefundStatusResponse
from app.auth import verify_jwt
from app.crypto import decrypt_ssn
from app.queue_handler import queue_irs_lookup
from app.ml_inference import predict_eta
import redis

# Redis client setup (used as cache)
redis_client = redis.Redis(host="localhost", port=6379, db=0)

# OAuth2 scheme for extracting JWT token
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

from app.routes_batch import router as batch_router

# Initialize FastAPI app
app = FastAPI()
app.include_router(batch_router)

@app.post("/refund/status", response_model=RefundStatusResponse)
async def get_refund_status(
    request: RefundStatusRequest,
    user=Depends(verify_jwt),
    background_tasks: BackgroundTasks = None
):
    """
    Endpoint to get the latest refund status.
    If not found in cache, queue a background IRS lookup and return AI predicted ETA.
    """
    ssn = decrypt_ssn(request.ssn_encrypted)
    refund_status = redis_client.get(f"refund:{ssn}")

    if refund_status is None:
        background_tasks.add_task(queue_irs_lookup, ssn)
        eta = predict_eta({"income": request.income})
        return RefundStatusResponse(
            refund_status="IN_PROGRESS",
            estimated_days=eta,
            message="Refund is processing. Estimated time until availability provided."
        )
    else:
        return RefundStatusResponse(
            refund_status=refund_status.decode(),
            message="Refund status retrieved."
        )
