"""
GDPR/CCPA-compliant user data deletion endpoint.
Allows users to request deletion of their personal data.
"""

from fastapi import APIRouter, HTTPException
import redis

router = APIRouter()
redis_client = redis.Redis(host="localhost", port=6379, db=0)

@router.delete("/user/data")
async def delete_user_data(user_id: str):
    """
    Deletes user's refund data and logs audit event.
    """
    keys_deleted = 0
    for key in redis_client.scan_iter(f"refund:*:{user_id}"):
        redis_client.delete(key)
        keys_deleted += 1

    # Audit log placeholder
    print(f"[AUDIT] Deleted {keys_deleted} keys for user: {user_id}")

    if keys_deleted == 0:
        raise HTTPException(status_code=404, detail="No data found for user")
    return {"message": f"Deleted {keys_deleted} records for user_id {user_id}"}
