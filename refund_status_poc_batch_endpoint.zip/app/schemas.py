"""
Defines Pydantic request and response models for FastAPI endpoints.
"""

from pydantic import BaseModel
from typing import Optional

class RefundStatusRequest(BaseModel):
    ssn_encrypted: str
    filing_date: str
    state: str
    income: float

class RefundStatusResponse(BaseModel):
    refund_status: str
    estimated_days: Optional[int] = None
    message: Optional[str] = None
