"""
FastAPI endpoint for batch refund status predictions using AI model fallback.
"""

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import List
from app.auth import verify_jwt
from app.batch_inference import predict_batch_eta

router = APIRouter()

class BatchRefundRequest(BaseModel):
    user_id: str
    income: float
    file_type: str = "e-file"
    state: str = "CA"

@router.post("/refund/batch-status")
async def batch_refund_status(
    users: List[BatchRefundRequest],
    _user=Depends(verify_jwt)
):
    """
    Returns AI-based refund ETA predictions for a batch of users.
    """
    user_data = [user.dict() for user in users]
    predictions = predict_batch_eta(user_data)
    return {"predictions": predictions}
