"""
AI fallback logic for refund ETA prediction.
Includes confidence score and fallback logging for user transparency.
"""

import numpy as np
from datetime import datetime, timedelta

def predict_eta_with_confidence(file_type: str, state: str, income: float) -> dict:
    """
    Mock AI prediction based on historical averages with confidence.
    Logs metadata for transparency and user trust.
    """
    avg_days = 21 if file_type == "e-file" else 28
    eta_days = int(np.clip(avg_days - (income / 10000), 7, avg_days))
    confidence = 0.85 if file_type == "e-file" else 0.75

    predicted_date = (datetime.utcnow() + timedelta(days=eta_days)).date().isoformat()

    log_fallback_event({
        "predicted_eta": predicted_date,
        "confidence": confidence,
        "file_type": file_type,
        "state": state,
        "timestamp": datetime.utcnow().isoformat()
    })

    return {
        "eta": predicted_date,
        "confidence": confidence,
        "source": "Estimated using secure AI model"
    }

def log_fallback_event(meta: dict):
    print(f"[AI_FALLBACK] {meta}")
