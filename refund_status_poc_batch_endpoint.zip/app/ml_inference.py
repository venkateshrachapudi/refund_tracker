"""
Handles AI model inference using ONNX for refund ETA prediction.
"""

import numpy as np

def predict_eta(input_features: dict) -> int:
    """
    Predicts estimated time to refund based on income.
    In a real version, replace this with ONNX runtime model inference.
    """
    return int(np.clip(30 - (input_features["income"] / 5000), 5, 30))
