"""
Session rotation logic for JWTs.
"""

import jwt
from datetime import datetime, timedelta

SECRET_KEY = "super_secret"
JWT_ALGORITHM = "HS256"

def generate_jwt(user_id: str, expires_delta: int = 1800):
    """
    Generates JWT token with short-lived expiration (30 min default).
    """
    expire = datetime.utcnow() + timedelta(seconds=expires_delta)
    payload = {"sub": user_id, "exp": expire}
    return jwt.encode(payload, SECRET_KEY, algorithm=JWT_ALGORITHM)
